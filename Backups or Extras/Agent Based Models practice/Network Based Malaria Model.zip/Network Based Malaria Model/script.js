document.getElementById('simulationForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const loadingSpinner = document.getElementById('loadingSpinner');
    const graphsContainer = document.getElementById('graphs');
    
    // Show loading spinner
    loadingSpinner.classList.remove('hidden');
    graphsContainer.innerHTML = '';
    
    // Get form data
    const formData = {
        humanPopulation: parseInt(document.getElementById('humanPopulation').value),
        mosquitoPopulation: parseInt(document.getElementById('mosquitoPopulation').value),
        houses: parseInt(document.getElementById('houses').value),
        temperature: parseFloat(document.getElementById('temperature').value)
    };
    
    try {
        const response = await fetch('/run-simulation', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Create containers for the graphs
            const popDiv = document.createElement('div');
            popDiv.id = 'populationGraph';
            popDiv.style.marginBottom = '20px';
            graphsContainer.appendChild(popDiv);
            
            const infDiv = document.createElement('div');
            infDiv.id = 'infectionGraph';
            graphsContainer.appendChild(infDiv);
            
            // Plot the graphs using the received data
            Plotly.newPlot('populationGraph', 
                data.plots.population.data,
                {
                    ...data.plots.population.layout,
                    height: 500,
                    width: 800
                }
            );
            
            Plotly.newPlot('infectionGraph', 
                data.plots.infection.data,
                {
                    ...data.plots.infection.layout,
                    height: 500,
                    width: 800
                }
            );
        } else {
            throw new Error(data.error || 'Unknown error occurred');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error running simulation: ' + error.message);
    } finally {
        loadingSpinner.classList.add('hidden');
    }
}); 